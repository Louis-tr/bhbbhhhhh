const Discord = require("discord.js");
const client = new Discord.Client();
const ayarlar = require("./ayarlar.json");
const chalk = require("chalk");
const ms = require("ms");
const moment = require("moment");
var Jimp = require("jimp");
const weather = require("weather-js");
const fs = require("fs");
const db = require("quick.db");
const express = require("express");
require("./util/eventLoader")(client);
const path = require("path");
const request = require("request");
const snekfetch = require("snekfetch");
const queue = new Map();
const YouTube = require("simple-youtube-api");
const ytdl = require("ytdl-core");
const app = express();
const http = require('http');
//let kanal = db.get(`emojiap1_${message.guild.id}`)
//client.on("ready", async member => {client.on("ready", async () => {
//kanal9.channel.send(emoji2); 
///const emoji2 = new Discord.RichEmbed()


app.get("/", (request, response) => {
  console.log("Hostlandı");
  response.sendStatus(200);
});
app.listen(process.env.PORT);
setInterval(() => {
  http.get(`http://ap-bot-louis-trr.glitch.me/`);
}, 280000) 

var prefix = ayarlar.prefix;

const log = message => {
  console.log(`${message}`);
};
//cmg
client.commands = new Discord.Collection();
client.aliases = new Discord.Collection();
fs.readdir("./cmg/", (err, files) => {
  if (err) console.error(err);
  log(`${files.length} komut yüklenecek.`);
  files.forEach(f => {
    let props = require(`./cmg/${f}`);
    log(`Yüklenen komut: ${props.help.name}.`);
    client.commands.set(props.help.name, props);
    props.conf.aliases.forEach(alias => {
      client.aliases.set(alias, props.help.name);
    });
  });
});

client.reload = command => {
  return new Promise((resolve, reject) => {
    try {
      delete require.cache[require.resolve(`./cmg/${command}`)];
      let cmd = require(`./cmg/${command}`);
      client.commands.delete(command);
      client.aliases.forEach((cmd, alias) => {
        if (cmd === command) client.aliases.delete(alias);
      });
      client.commands.set(command, cmd);
      cmd.conf.aliases.forEach(alias => {
        client.aliases.set(alias, cmd.help.name);
      });
      resolve();
    } catch (e) {
      reject(e);
    }
  });
};

client.load = command => {
  return new Promise((resolve, reject) => {
    try {
      let cmd = require(`./cmg/${command}`);
      client.commands.set(command, cmd);
      cmd.conf.aliases.forEach(alias => {
        client.aliases.set(alias, cmd.help.name);
      });
      resolve();
    } catch (e) {
      reject(e);
    }
  });
};

client.unload = command => {
  return new Promise((resolve, reject) => {
    try {
      delete require.cache[require.resolve(`./cmg/${command}`)];
      let cmd = require(`./cmg/${command}`);
      client.commands.delete(command);
      client.aliases.forEach((cmd, alias) => {
        if (cmd === command) client.aliases.delete(alias);
      });
      resolve();
    } catch (e) {
      reject(e);
    }
  });
};

client.elevation = message => {
  if (!message.guild) {
    return;
  }
  let permlvl = 0;
  if (message.member.hasPermission("BAN_MEMBERS")) permlvl = 2;
  if (message.member.hasPermission("ADMINISTRATOR")) permlvl = 3;
  if (message.author.id === ayarlar.sahip) permlvl = 4;
  return permlvl;
};

var regToken = /[\w\d]{24}\.[\w\d]{6}\.[\w\d-_]{27}/g;

client.on("warn", e => {
  console.log(chalk.bgYellow(e.replace(regToken, "that was redacted")));
});

client.on("error", e => {
  console.log(chalk.bgRed(e.replace(regToken, "that was redacted")));
});
//sil
client.on('messageDelete', async message => {
db.set(`louis_${message.channel.id}`, { kanal: message.channel.id, mesaj: message.content, sahip: message.author.id, tarih: message.createdAt })
})
//sil
  

//guvenlik
client.on('guildMemberAdd',async member => {
  let user = client.users.get(member.id);
  let kanal = client.channels.get(db.fetch(`guvenlik${member.guild.id}`)) 
       const Canvas = require('canvas')
       const canvas = Canvas.createCanvas(360,100);
       const ctx = canvas.getContext('2d');
  
  const resim1 = await Canvas.loadImage('https://cdn.discordapp.com/attachments/597433546868654106/627428441695977497/gvnlk-spheli.png')
    const resim2 = await Canvas.loadImage('https://cdn.discordapp.com/attachments/597433546868654106/627427731407241226/gvnlk-gvnli.png')
    const kurulus = new Date().getTime() - user.createdAt.getTime();
    const gün = moment(kurulus).format('dddd');  
    var kontrol;
      if (kurulus > 2629800000) kontrol = resim2
    if (kurulus < 2629800000) kontrol = resim1

       const background = await Canvas.loadImage('https://cdn.discordapp.com/attachments/597433546868654106/627425996454232064/gvnlk-arka.png');
       ctx.drawImage(background, 0, 0, canvas.width, canvas.height);
   
  const avatar = await Canvas.loadImage(member.user.displayAvatarURL);
  ctx.drawImage(kontrol,0,0,canvas.width, canvas.height)
  ctx.beginPath();
    ctx.lineWidth = 4;
  ctx.fill()
    ctx.lineWidth = 4;
  ctx.arc(180, 46, 36, 0, 2 * Math.PI);
    ctx.clip();
  ctx.drawImage(avatar, 143,10, 73, 72  );

   if (!kanal) return
       const attachment = new Discord.Attachment(canvas.toBuffer(), 'güvenlik.png');
    kanal.send(attachment)
});
//guvenlik


//otorol
client.on("guildMemberAdd", async member => {
let kanal = await db.fetch(`otok_${member.guild.id}`)  
let rol = await db.fetch(`otorol_${member.guild.id}`)   
let mesaj =  db.fetch(`otomesaj_${member.guild.id}`)  
if(!kanal) return

if(!mesaj) {
  
  client.channels.get(kanal).send('<a:evet2:734376367893905459>Otomatik Rol Verildi Seninle Beraber `'+member.guild.memberCount+'` Kişiyiz! Hoşgeldin! `'+member.user.username+'`')
member.addRole(rol)
  return
} 

if(mesaj) {
  var mesajs = await db.fetch(`otomesaj_${member.guild.id}`).replace("-uye-", `${member.user.tag}`).replace("-rol-", `${member.guild.roles.get(rol).name}`).replace("-server-", `${member.guild.name}`).replace("-uyesayisi-", `${member.guild.memberCount}`).replace("-botsayisi-", `${member.guild.members.filter(m => m.user.bot).size}`).replace("-bolge-", `${member.guild.region}`).replace("-kanalsayisi-", `${member.guild.channels.size}`)
  member.addRole(rol)
  client.channels.get(kanal).send(mesajs)

}  
  
});

//otorol

//sayaç
client.on("guildMemberAdd", member => {
  const profil = JSON.parse(fs.readFileSync("./json/sayac.json", "utf8"));
  if (!profil[member.guild.id]) return;
  if (profil[member.guild.id]) {
    let sayaçkanalID = profil[member.guild.id].kanal;
    let sayaçsayı = profil[member.guild.id].sayi;
    let sayaçkanal = client.channels.get(sayaçkanalID);
    let aralık = parseInt(sayaçsayı) - parseInt(member.guild.members.size);
    sayaçkanal.sendMessage(
      "<a:Gir:734376370682986546> `" +
        `${member.user.tag}` +
        "` Sunucuya Katıldı \n `" +
        sayaçsayı +
        "` Kişi Olmamıza `" +
        aralık +
        "` Kişi Kaldı! \n<a:tip3:734376370154504253> `" +
        member.guild.members.size +
        "` Kişiyiz!"
    );
  } 
});

client.on("guildMemberRemove", member => {
  const profil = JSON.parse(fs.readFileSync("./json/sayac.json", "utf8"));
  if (!profil[member.guild.id]) return;
  if (profil[member.guild.id]) {
    let sayaçkanalID = profil[member.guild.id].kanal;
    let sayaçsayı = profil[member.guild.id].sayi;
    let sayaçkanal = client.channels.get(sayaçkanalID);
    let aralık = parseInt(sayaçsayı) - parseInt(member.guild.members.size);
    sayaçkanal.sendMessage(
      "<a:Cik:734376370221744140> `" +
        `${member.user.tag}` +
        "` Sunucudan Ayrıldı! \n `" +
        sayaçsayı +
        "` Kişi Olmamıza `" +
        aralık +
        "` Kişi Kaldı! \n<a:tip3:734376370154504253> `" +
        member.guild.members.size +
        "` Kişiyiz!"
    );
  }
});
//sayâç
//BAN KORUMA --------------------------------

client.on("guildBanAdd", async (guild, user) => {
  const entry = await guild
    .fetchAuditLogs({ type: "MEMBER_BAN_ADD" })
    .then(audit => audit.entries.first());
  let banlimit = await db.fetch(`banlimit_${guild.id}`);
  let kullanıcıban = await db.fetch(
    `banlimitkullanici_${guild.id}_${entry.executor.id}`
  );

  if (banlimit) {
    if (entry.executor.id !== guild.owner.user.id) {
      if (entry.executor.bot) return;
      await db.add(`banlimitkullanici_${guild.id}_${entry.executor.id}`, 1);

      try {
        guild
          .member(entry.executor)
          .roles.filter(a => a.hasPermission("BAN_MEMBERS"))
          .forEach(x => guild.member(entry.executor).removeRole(x.id));
        guild.owner.user.send(`

**Sunucundan Bir Yetkili Ban Koruma Limitine Ulaştı ve Ban Yetkisi Olan Tüm Rolleri Alındı!**\n**Bilgileri:**
\n**Kullanıcı:**\  ${entry.executor} | ${entry.executor.id} 
\n\`Katılım Tarihi:\` 
\n•**Discord:** ${moment(entry.executor.createdAt).format(
          "DD/MM/YYYY | HH:mm:ss"
        )} 
•**Sunucu:** ${moment(guild.member(entry.executor).joinedAt).format(
          "DD/MM/YYYY | HH:mm:ss"
        )}`);
      } catch (err) {}
      db.delete(`banlimitkullanici_${guild.id}_${entry.executor.id}`);
    }
  }
});
//ban
///////////SAHİBİM BELİRDİ!/////////////
client.on("message", async msg => {
  const request = require("node-superfetch");
  const db = require("quick.db");
  const ms = require("parse-ms");
  let timeout = 1200000; 
  let louis = await db.fetch(`louiss_${msg.author.id}`);
  let i = ayarlar.sahip;
  if (msg.author.id == i ) {
    if (louis !== null && timeout - (Date.now() - louis) > 0) {
      let time = ms(timeout - (Date.now() - louis));
    } else {
      if (msg.author.bot) return;
      if (msg.content.length > 1) {
        db.set(`louiss_${msg.author.id}`, Date.now());
        var embed = new Discord.RichEmbed()
          .setDescription(
            `<a:fire31:734375735103455272> | __***Sahibim Burada Belirdi!***__  <@${msg.author.id}> | <a:fire31:734375735103455272>`
          )
          .setColor("#03fcf8");
        msg.channel.send(embed).then(m => m.delete(10000))
      }
                                     }
                                     
                                     } else if (i == undefined) {
  }
  if (!i) return;
});
///SAHİBİM BELİRDİ!
//gold
client.on("message", async msg => {  
const goldüyetext = new Discord.RichEmbed()
.setDescription(`** <a:k_:734314257071734804> Gold Üyemiz Aramıza Katıldı!<a:k_:734314257071734804>**`)
.setColor("#c987ff")
let zamanasimi = 1200000;
let goldlar = await db.fetch(`gold${msg.author.id}`)
let goldb = await db.fetch(`goldsure${msg.author.id}`);
if (goldlar == 'gold') {  
if (goldb !== null && zamanasimi - (Date.now() - goldb) > 0) {
let time = ms(zamanasimi  - (Date.now() - goldb)); } else {
if(msg.author.bot) return;   
if (msg.content.length > 1) {
db.set(`goldsure${msg.author.id}`, Date.now());
msg.channel.send(goldüyetext).then(msg => { msg.delete(10000) })}}}})
//gold
  // sunucuya eklendim ve atıldım
client.on("guildCreate", guild => { 
let add = client.channels.get("734519351696162837")
const eklendim = new Discord.RichEmbed()

.setTitle(`Sunucuya Eklendim`)
.setTimestamp()
.setColor("GREEN")
.setThumbnail(guild.iconURL)
.addField(`Sunucu İsmi`,guild.name)
.addField(`Sunucu ID`, guild.id)
.addField(`Kurucu`,guild.owner.user.tag)
.addField(`Kurucu ID`,guild.owner.user.id)
.addField(`Üye Sayısı`,guild.memberCount)

add.send(eklendim)

});

client.on("guildDelete", guild => {
let remove = client.channels.get("734519351696162837")
const atildim = new Discord.RichEmbed()

.setTitle(`Sunucudan Atıldım`)
.setTimestamp()
.setColor("RED")
.setThumbnail(guild.iconURL)
.addField(`Sunucu İsmi`,guild.name)
.addField(`Sunucu ID`, guild.id)
.addField(`Kurucu`,guild.owner.user.tag)
.addField(`Kurucu ID`,guild.owner.user.id)
.addField(`Üye Sayısı`,guild.memberCount)

remove.send(atildim)

});
  // sunucuya eklendim ve atıldım



//emoji rol

client.on("message", async message => {
  if(message.author.bot) return;
  var spl = message.content.split(" ");
  if(spl[0] === "!emojirol") {
  var args = spl.slice(1);
  var msg, emoji, rol, ee = "";
  try {
    msg = await message.channel.fetchMessage(args[0])
    emoji = args[1]
    rol = message.guild.roles.get(args[2]) || message.mentions.roles.first();
    await msg.react(emoji)
    if(!rol) throw new Error("YAZACAĞIN ROLÜ SİKEUİM")
  } catch(e) {
    if(!e) return;
    e = (""+e).split("Error:")[1]
    if(e.includes("Cannot read property") || e.includes("Invalid Form Body")) {
      message.channel.send(`:warning: | Mesaj id hatalı!`)
    } else if(e.includes("Emoji")) {
      message.channel.send(`:warning: | Girdiğiniz emoji mesaja eklenemiyor!`)
    } else if(e.includes("ROLÜ")) {
      message.channel.send(`:warning: | Girdiğiniz rol geçersiz!`)
    }
    ee = e
  }
   if(ee) return;
   message.channel.send(`:white_check_mark: | Emoji rol, **${msg.content}** içerikli mesaja atandı!`)
   db.push(`tepkirol.${message.guild.id}`, {
     kanal: msg.channel.id,
     rol: rol.id,
     mesaj: msg.id,
     emoji: emoji
   })
  } else if(spl[0] === "!emojirol-log") {
    var args = spl.slice(1)
    var chan = message.guild.channels.get(args[0]) || message.mentions.channels.first()
    if(!chan) return message.channel.send(`:warning: | Kanal etiketle veya id gir`)
    db.set(`tepkirolkanal.${message.guild.id}`, chan.id)
    message.channel.send(":white_check_mark: | Tepkirol log kanalı "+ chan+ " olarak ayarlandı!")
  }
})

client.on("raw", async event => {
  if(event.t === "MESSAGE_REACTION_ADD") {
    var get = db.get(`tepkirol.${event.d.guild_id}`)
    if(!get) return;
    var rol = get.find(a => a.emoji === event.d.emoji.name && a.mesaj === event.d.message_id)
    if(!rol) return;
    rol = rol.rol
    var member = await client.guilds.get(event.d.guild_id).fetchMember(event.d.user_id)
    member.addRole(rol);
    var kanal = db.get(`tepkirolkanal.${event.d.guild_id}`)
    if(kanal) {
      var kanal = client.channels.get(kanal)
      kanal.send(member + " kullanıcısına, **" + kanal.guild.roles.get(rol).name + "** adlı rol verildi!")
    }
  } else if(event.t === "MESSAGE_REACTION_REMOVE") {
    var get = db.get(`tepkirol.${event.d.guild_id}`)
    if(!get) return;
    var rol = get.find(a => a.emoji === event.d.emoji.name && a.mesaj === event.d.message_id)
    if(!rol) return;
    rol = rol.rol
    var member = await client.guilds.get(event.d.guild_id).fetchMember(event.d.user_id)
    member.removeRole(rol);
    var kanal = db.get(`tepkirolkanal.${event.d.guild_id}`)
    if(kanal) {
      var kanal = client.channels.get(kanal)
      kanal.send(member + " kullanıcısından, **" + kanal.guild.roles.get(rol).name + "** adlı rol alındı!")
    }
  }
})

//emoji rol
//süreli-rol
setInterval(async() => {
    var mem = [];
    client.guilds.forEach(async guild => {
    guild.members.forEach(async member => {
    let m = await db.fetch(`kullanıcı${guild.id}_${member.id}`)
    if(m){
    let time = await db.fetch(`rolint${guild.id}_${member.id}`)
    if(!time) return;
    let sures = await db.fetch(`rolsure${guild.id}_${member.id}`)
    let timing = Date.now() - time
    let rl = await db.fetch(`roliste_${guild.id}_${member.id}`)
    
    if(timing >= sures) {
      guild.members.find(x => x.id === member.id).removeRole(rl)
      db.delete(`kullanıcı${guild.id}_${member.id}`)
      db.delete(`rolsure${guild.id}_${member.id}`)
      db.delete(`rolint${guild.id}_${member.id}`)
    }
  }
 })
})    
}, 5000)
//süreli-rol
//snipe
client.on('messageDelete', message => {
  db.set(`snipe.mesaj.${message.guild.id}`, message.content)
  db.set(`snipe.id.${message.guild.id}`, message.author.id)
})
//snipe
client.login(ayarlar.token);

