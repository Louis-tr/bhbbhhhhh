const Discord = require('discord.js');
const fs = require('fs');
const profil = JSON.parse(fs.readFileSync("./json/sayac.json", "utf8"));

exports.run = (client, message, args) => {
  if(!message.member.hasPermission("MANAGE_GUILD")) return message.channel.send("<a:Hyr3:734376365058686996> Bu Komutu Kullanabilmek İçin `Sunucuyu Yönet`  Yetkisine Sahip Olaman Gerekli!")
  if(!profil[message.guild.id]) return message.channel.send("<a:Hyr3:734376365058686996> Sunucunuzda **Sayaç Sistemi** Ayarlanmamış!")
  if(profil[message.guild.id]) {
    delete profil[message.guild.id]
    message.channel.send("<a:evet2:734376367893905459>Sayaç Sıfırlandı!")
  }
};

exports.conf = {
  enabled: true,
  guildOnly: true,
  aliases: ["sayaçsıfırla","sk","sayaç-kapat","sayaçkapat"]
};

exports.help = {
  name: 'sayaç-sıfırla',
  description: 'sayaç sistemi kapatma gösterir.',
  usage: 'sayaç-sıfırla'
};
