const Discord = require('discord.js')
const db = require('quick.db')

exports.run = async (client, message ,args) => {
        const emoji = client.emojis.random().url;
  
const emoji2 = new Discord.RichEmbed()
        .setColor("#0000ff")
        .setTimestamp() 
        .setImage(emoji)
        .setFooter(`${client.user.username} - Random Emoji`, client.user.avatarURL)

        message.channel.send(emoji2)
  };
exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ['random-emoji'],
  permLevel: 0,
};

exports.help = {
  name: "Random-Emoji",
  
};
