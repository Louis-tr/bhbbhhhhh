const Discord = require('discord.js');
const db = require('quick.db');

exports.run = async (bot, message, args) => {
  await db.delete(`guvenlik${message.guild.id}`)
  return message.channel.send("Güvenlik **sıfırlandı!**<a:evet2:734376367893905459>")
};

exports.conf = {
  enabled: true, 
  guildOnly: false, 
  aliases: [], 
  permLevel: 2
};
exports.help = {
  name: 'güvenlik-sıfırla', 
  description: '', 
  usage: '' 
};