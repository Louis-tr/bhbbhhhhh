const Discord = require('discord.js')
exports.run = async(client, message, args) => {
let dcsdavet = "https://discord.com/api/oauth2/authorize?client_id=734154453334360106&permissions=8&scope=bot"
let dcsdestek = "https://discord.gg/RnWu8Ap"

 const embed = new Discord.RichEmbed()
  .setAuthor("AP BOT")
.setDescription(`<a:evet2:734376367893905459>**__[Davet Linki](${dcsdavet})__** \n \n <a:evet2:734376367893905459>**__[Destek Sunucum](${dcsdestek})__**\n `)
 .setFooter(`AP BOT`)
.setColor("RANDOM")
.setTimestamp()
message.channel.send(embed); 
} 
exports.conf = {
  enabled: true,
  guildOnly: true,
  aliases: ["invite"],
  permLevel: 0
};

exports.help = {
  name: 'davet',
  description: 'Bot Davetini Verir.',
  usage: 'davet'
};