const Discord = require('discord.js');
const db = require('quick.db')

exports.run = async(client, message, args) => {
  
  
  const sayi = args[0]
  if (sayi > 101) return message.reply("En Az `1 - 100` Arasında Bir Tam Sayı Değeri Girmelisiniz<a:Hyr3:734376365058686996>")

  let messages = await message.channel.fetchMessages({
    limit: sayi
  });

     let mesaj = await message.channel.bulkDelete(messages, true);
  
  if (!mesaj.size) {
    return message.reply("En Az `1 - 100` Arasında Bir Tam Sayı Değeri Girmelisiniz<a:Hyr3:734376365058686996>")
  }


          var embed = new Discord.RichEmbed()
          .setDescription(
            `<a:fire31:734375735103455272> | <@${message.author.id}>${mesaj.size} Adet Mesaj Başarı İle Uzaya Fırlatıldı. <a:evet2:734376367893905459>`
          )
          .setColor("#03fcf8");
        message.channel.send(embed).then(m => m.delete(10000))
};

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ["sil"],
  permLevel: 0
};

exports.help = {
  name: 'temizle',
  description: 'Ban limiti.',
  usage: 'banlimit',
  kategori: 'yetkili'
};