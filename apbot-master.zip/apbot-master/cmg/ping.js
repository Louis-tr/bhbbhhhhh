const Discord = require('discord.js')

exports.run = async (client, message, args, color) => {

    let start = Date.now(); message.channel.send( 'Pong! ').then(message => { 
    let diff = (Date.now() - start); 
    let API = (client.ping).toFixed(2)
        
        let embed = new Discord.RichEmbed()
        .setTitle(`Bot Pingim !`)
        .setColor(0xff2f2f)
        .addField("Mesaj Gecikmesi<a:online:695616006126698496>", `${diff}ms`, true)
        .addField("Bot Gecikmesi<a:online:695616006126698496>", `${API}ms`, true)
        message.edit(embed);
      
    });

}

exports.conf = {
    enabled: true,
    guildOnly: false,
    aliases: ['pg'],
    permLevel: 0
  };

exports.help = {
    name: 'ping',
    category: 'INFO'
} 
