const Discord = require('discord.js');
const db = require('quick.db')
exports.run = async (client, message, args) => {
let kullanıcı = await db.fetch(`gold${message.author.id}`, 'gold');

  if( kullanıcı == undefined){
message.reply("****Bu Komut Gold Üyelere Özeldir .. Kullanabilmek İçin Gold Üyeliği Almanız Lazım ****")
  }else{
      if( kullanıcı == "gold"){
        }
  const yazi = args.slice(0).join('+'); 

  if(!yazi) return message.channel.send(`Lütfen yazı yazın!`)
   
  const kuaty = `https://flamingtext.com/net-fu/proxy_form.cgi?imageoutput=true&script=alien-glow-logo&text=${yazi}`
  
  .replace(' ', '+')

  

  const kuaty2 = new Discord.RichEmbed()

  .setTitle(`İşte Logon Burada`)

  .setColor("RANDOM")

  .setImage(kuaty)

  message.channel.send(kuaty2)
}
}
exports.conf = {

    enabled: true,

    guildOnly: false,

    aliases: [],

    permLevel: 0

}
exports.help = {
  name: "alien-glow"

};
