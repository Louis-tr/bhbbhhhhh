const Discord = require('discord.js');
const db = require('quick.db')
exports.run = async(client, message, args) => { 
let kanal = await db.fetch(`otok_${message.guild.id}`)  
let rol = await db.fetch(`otorol_${message.guild.id}`)   
let mesaj =  db.fetch(`otomesaj_${message.guild.id}`)  
  if (!message.member.hasPermission("ADMINISTRATOR")) return message.channel.send(` Bu komutu kullanabilmek için "\`Yönetici\`" yetkisine sahip olmalısın.<a:Hyr3:734376365058686996>`);
  
  
  if(!kanal) return message.channel.send('<a:Hyr3:734376365058686996> Otorol Zaten Kapalı')

  db.delete(`otok_${message.guild.id}`)   
  db.delete(`otorol_${message.guild.id}`)   
  db.delete(`otomesaj_${message.guild.id}`)
 message.channel.send('Otorol **'+message.guild.name+'** Sunucusunda Devre Dışı Bırakılmıştır.<a:evet2:734376367893905459>')

};
exports.conf = {
  enabled: true,  
  guildOnly: false, 
  aliases: [], 
  permLevel: 0
};

exports.help = {
  name: 'oto-rol-kapat',
  description: 'taslak', 
  usage: 'otorolkapat'
};