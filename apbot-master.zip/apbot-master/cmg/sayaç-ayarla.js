const Discord = require('discord.js');
const fs = require('fs')
const profil = JSON.parse(fs.readFileSync("./json/sayac.json", "utf8"));
exports.run = (client, message, args) => {
  if(!message.member.hasPermission("MANAGE_GUILD")) return message.reply("<a:Hyr3:734376365058686996> Bu Komutu Kullanabilmek İçin `Sunucuyu Yönet` Yetkisine Sahip Olmalısın!")
  let mkanal = message.mentions.channels.first()
  let sayı = args.slice(1);
  if(!mkanal) return message.reply("<a:Hyr3:734376365058686996> Bir Kanal Etiketlemelisin!")
  if(!sayı) return message.reply("<a:Hyr3:734376365058686996> Bir Sayı Girmelisin!")
  if(sayı < message.guild.members.size) return message.reply("<a:Hyr3:734376365058686996> Sayaç Sayısı Sunucudaki Üye Sayısından Fazla Olmalıdır!\n**Üye Sayısı:** " + message.guild.members.size)
  if(sayı && mkanal) {
    if(!profil[message.guild.id]) {
      profil[message.guild.id] = {
        sayi: sayı,
        kanal: mkanal 
      }
    }
    if(profil[message.guild.id]) {
      profil[message.guild.id].sayi = sayı;
      profil[message.guild.id].kanal = mkanal.id;
    }
    fs.writeFile("./json/sayac.json", JSON.stringify(profil), (err) => {
        if(err) message.channel.send("Hata: " + err)
    })
    let embed = new Discord.RichEmbed()
      .setTitle("<a:evet2:734376367893905459> Sayaç Ayarlandı ")
      .setDescription(`<a:evet2:734376367893905459> **Sayaç Kanalı:** ${mkanal}\n **Sayaç:** \`${sayı}\``)
      .setFooter("Ap bot", message.author.avatarURL)
      .setColor("RANDOM")
      .setTimestamp()
    message.channel.send(embed)
  }
};
exports.conf = {
  enabled: true,
  guildOnly: true,
  aliases: []
};
exports.help = {
  name: 'sayaç',
  description: 'sayaç sistemi',
  usage: 'sayaç'
};