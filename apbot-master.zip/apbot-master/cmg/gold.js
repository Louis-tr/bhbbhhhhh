const Discord = require('discord.js')
const db = require("quick.db")
const ayarlar = require('../ayarlar.json');
exports.run = async(client, message, args) => {

let ownerid = `690305221544378379`
//--------------------------------------------------------------------------------------

  
if(args[0] == 'ekle') {
let owner = [ownerid];
if (owner.includes(message.author.id)) {
let user = message.guild.member(message.mentions.users.first()) || message.guild.members.get(args[0]);
if (!user) return message.reply("**Dostum Etiket Atmayı Unuttun**");
db.set(`gold${user.id}`, 'gold')
message.channel.send(`${user} Gold Üye Olarak Kaydedildi!`)}}
  
  
  
  
if(args[0] == 'kaldır') {
let owner = [ownerid];
if (owner.includes(message.author.id)) {
let user = message.guild.member(message.mentions.users.first()) || message.guild.members.get(args[0]);
if (!user) return message.reply("**Dostum Etiket Atmayı Unuttun**");
db.delete(`gold${user.id}`)
message.channel.send(`${user}'in Gold Üyeliği Silindi!`)}}  
/*
!gold ekle
!gold sorgula 
!gold kaldır  
  */
if(args[0] == 'sorgula') {
var user = message.mentions.users.first() || message.author;
let yarrak = db.fetch(`gold${user.id}`)
let u = message.mentions.users.first() || message.author;
if(u.bot === true) {message.channel.send(new Discord.RichEmbed()
.setDescription("Botlar Gold Olamaz!")
.setColor("ff0000"))}  
else {
var ks = [];  
if(yarrak == null) ks = `❌ \`Değil!\``
if(yarrak != null) ks = `✅ \`${yarrak}\``
message.channel.send(new Discord.RichEmbed()
.setColor("GOLD")
.setAuthor(`${user.username}`, user.avatarURL)
.setThumbnail(user.avatarURL)                     
.setTitle(`Gold Sorgulama Bilgisi:`)                 
.addField(`**Kullanıcı:**`, `<@${user.id}>`, true)
.addField("**Kullanıcı Gold mi?**", ks)
.setFooter(`${client.user.username} Gold Sistemi!`)   
.setTimestamp())}    }
    

}
exports.conf = {
  enabled: true, 
  guildOnly: false,
  aliases: [],
  permLevel: 0
};

exports.help = {
  name: 'gold'
};

/*
 https://dcs-hastebin-4.glitch.me/Wlss6or6GJ  => komutlar/gold.js
 https://dcs-hastebin-4.glitch.me/EhYUxZ7VwY  => komutlar/market.js
 https://dcs-hastebin-4.glitch.me/zJvBD9ETKu  => komutlar/günlük.js
 https://dcs-hastebin-4.glitch.me/5N0xAY4I9m  => komutlar/para.js
 https://dcs-hastebin-4.glitch.me/JEutgLzYoC  => komutlar/para-ekle.js
 https://dcs-hastebin-4.glitch.me/Qi6CLY8lvA  => komutlar/para-sil.js
 https://dcs-hastebin-4.glitch.me/sFO0SHTvbw  => komutlar/satınal.js
 https://dcs-hastebin-4.glitch.me/wBBiqKWkIp  => Maine!
by Except!


*/