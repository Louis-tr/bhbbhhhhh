const Discord = require("discord.js");

exports.run = async (client, message, level) => {
 
  let items = [
    "Ak-47",
    "P90",
    "Deagle",
    "Tec-9",
    "M4A4",
    "Five-SeveN",
    "Awp",
    "M4A1-S",
    "Glock-18",
    "SSG 08",
    "P250",
    "Cz75",
    "Famas",
    "Mac-10",
    "Mag-7",
    "Mp7",
    "Mp9",
    "P2000",
    "R8 Revolver",
    "Ump-45",
    "Usp-S",
    "Çift Baretta",
    "Negev",
    "M249"
  ];

  let item = items[Math.floor(Math.random() * items.length)];
  //DCS EKİBİ
  message.channel
    .send(`**${message.author}** Kasa Açılıyor...`)
    .then(async msg => {
      setTimeout(() => {
        msg.edit(
          new Discord.RichEmbed()

            .setColor("RANDOM")
            .setDescription("```🔪|🔫|🔪|🔫|🔪|🔫|🔪\n🔫|🔪|🔫|🔪|🔫🔪|🔫```")
        );
      }, 2000);
      setTimeout(() => {
        msg.edit(
          new Discord.RichEmbed()
            .setColor("RANDOM")
            .setDescription("```🔫|🔪|🔫|🔪|🔫|🔪|🔫\n🔪|🔫|🔪|🔫|🔪|🔫|🔪```")
        );
      }, 3000);
      setTimeout(() => {
        msg.edit(
          new Discord.RichEmbed()
            .setColor("RANDOM")
            .setDescription("```🔪|🔫|🔪|🔫|🔪|🔫|🔪\n🔫|🔪|🔫|🔪|🔫🔪|🔫```")
        );
      }, 4000);
      setTimeout(() => {
        msg.edit(
          new Discord.RichEmbed()
            .setColor("RANDOM")
            .setDescription("```🔫|🔪|🔫|🔪|🔫|🔪|🔫\n🔪|🔫|🔪|🔫|🔪|🔫|🔪```")
        );
      }, 5000);
      setTimeout(() => {
        msg.edit(
          new Discord.RichEmbed()
            .setColor("RANDOM")
            .setDescription("```🔪|🔫|🔪|🔫|🔪|🔫|🔪\n🔫|🔪|🔫|🔪|🔫🔪|🔫```")
        );
      }, 6000); 
      setTimeout(() => {
        msg.edit(
          new Discord.RichEmbed()
            .setColor("RANDOM")
            .setDescription("```🔫|🔪|🔫|🔪|🔫|🔪|🔫\n🔪|🔫|🔪|🔫|🔪|🔫|🔪```")
        );
      }, 7000);
      setTimeout(() => {
        msg.edit(
          new Discord.RichEmbed()
            .setColor("RANDOM")
            .setDescription("```🔪|🔫|🔪|🔫|🔪|🔫|🔪\n🔫|🔪|🔫|🔪|🔫🔪|🔫```")
        );
      }, 8000);
      setTimeout(() => {
        msg.edit(
          new Discord.RichEmbed()
            .setColor("RANDOM")
            .setDescription("```🔫|🔪|🔫|🔪|🔫|🔪|🔫\n🔪|🔫|🔪|🔫|🔪|🔫|🔪```")
        );
      }, 9000);
      setTimeout(() => {
        msg.edit(
          new Discord.RichEmbed()
            .setColor("RANDOM")
            .setDescription("```T 🎉 E 🎉 B 🎉 R 🎉 İ 🎉 K 🎉 L 🎉 E 🎉 R```")
        );
      }, 10000);
      setTimeout(() => {
        msg.edit(
          new Discord.RichEmbed()
            .setColor("RANDOM")
            .setDescription(`**🎁 ${item} Çıktı!**`)
        );
      }, 11000);
    }); 
};

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ["csgo-kasa"],
  permLevel: 0
};

exports.help = {
  name: "kasa"
  
};