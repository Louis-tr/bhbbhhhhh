const Discord = require ("discord.js");

exports.run = (client, message) => {
  
  
  var embed = new Discord.RichEmbed()
  
  .setColor("RANDOM")
  .setDescription(`Artık kralsın!`)
  .setImage(`https://media.giphy.com/media/Ze3NJ93TTdmL97EkR7/giphy.gif`)
  
  message.channel.send(embed)
  
}
module.exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: [],
  kategori: "",
  permLevel: 0
};

module.exports.help = {
  name: 'kral-ol',
  description: 'Kral olursunuz',
  usage: 'kral-ol'
};