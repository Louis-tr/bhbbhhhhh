const Discord = require("discord.js");
const moment = require("moment");
const os = require('os');
require("moment-duration-format");
exports.run = async (bot, message, args) => {
   const seksizaman = moment.duration(bot.uptime).format(" D [gün], H [saat], m [dakika], s [saniye]");
   const istatistikler = new Discord.RichEmbed()
  .setColor('RANDOM')
  .setFooter('AP Bot  \'Buyur benim istatistiklerim', bot.user.avatarURL)
  .addField(" ___***Botun Sahibi***___", "<@690305221544378379>")
  .addField(" ___***Bellek kullanımı***___", (process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2) + ' MB', true)  
  .addField("____***Çalışma süresi***___", seksizaman)
  .addField(" ___***Kullanıcılar***___" , bot.guilds.reduce((a, b) => a + b.memberCount, 0).toLocaleString(), true)
  .addField(" ___***Sunucular***___", bot.guilds.size.toLocaleString(), true)
  .addField(" ___***Kanallar***___", bot.channels.size.toLocaleString(), true)
  .addField(" ___***Discord.JS sürüm***___", "v"+Discord.version, true)
  .addField(" ___***Node.JS sürüm***___", `${process.version}`, true)
  .addField(" ___***Ping***___", bot.ping+" ms", true)
  .addField(" ___***CPU***___", `\`\`\`md\n${os.cpus().map(i => `${i.model}`)[0]}\`\`\``)
  .addField(" ___***Bit***___", `\`${os.arch()}\``, true)
  .addField(" ___***İşletim Sistemi***___", `\`\`${os.platform()}\`\``) 
  
  
 return message.channel.send(istatistikler);
  };

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: [ 'i', 'YEDEK KOMUT2'],
  permLevel: 0
};

exports.help = {
  name: "istatistik",
  description: "Bot i",
  usage: "istatistik"
};
