const Discord = require("discord.js");
const db = require('quick.db');

exports.run = async(client, message, args) => {
  

 if(message.author.id !== "690305221544378379") return message.channel.send(" Bu komutu sadece geliştiricim kullanabilir.<a:Hyr2:734376354069610566>");
  if (!args[0]) return message.channel.send(`Yanlış Kullanım  **!bakım aç** **!bakım kapat**<a:Hyr2:734376354069610566>`)

  if(args[0] == 'kapat') {
    db.delete(`apbot`)
    message.channel.send(`**Bot Başarıyla Bakımdan Çıkarıldı**<a:evet2:734376353712963625>`)
    return;
  }
  

  if(args[0] == 'aç') {
  
db.set(`apbot`,'aktif')
    message.channel.send(`**Bot Başarıyla Bakıma Alındı**<a:evet2:734376353712963625>`)
}}
exports.conf = { 
  enabled: true,
  guildOnly: false,
  aliases: [],
  permLevel: 2
};

exports.help = {
  name: "bakım"

};