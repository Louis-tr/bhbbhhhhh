 const Discord = require('discord.js');
 const ayarlar = require('../ayarlar.json');

 exports.run = (client, message, params) => {
   const ap = new Discord.RichEmbed()
     .setTitle('<a:k_:734314257071734804> __***Yardım Komutları***__<a:k_:734314257071734804>')
     .setColor("#00fffb")
     .setTimestamp() 
     .setThumbnail(client.user.avatarURL)
     .addField("<a:moderasyon:734375740161916978> | __***Moderasyon***__", '`!istatisik`, `!say`, `!güvenlik-ayarla`, `!güvenlik-sıfırla`, `!oto-rol-ayarla`, `!oto-rol-kapat`, `!otorol-mesaj-ayarla`, `!sayaç`, `!sayaç-sıfırla`, `!sil`, `!davet`')
     .addField("<a:ec:734333556284850177> | __***Eğlence***__", '`!kasa`, `!adam-ol`, `!kral-ol`, `!ilk-yazan-kazanır @Louis`')
     .addField("<a:fire31:734375735103455272> | __***Kullanıcı Komutları***__", '`!ping`, `!süreli-rol`, `!snipe`, `!random-emoji`')
     .addField("<a:evet2:734376353712963625> | __***Koruma***__  ", '`!banlimit`')
     .addField("<a:gold:734373888884080640> | __***Gold***__", '`!günlük`, `!market`, `!satınal <ürün-kodu>`, `!para`') 
     .addField("<a:kb:734333937526112368> | __***Yapımcım Komutları***__", '`!gold ekle`, `!gold sorgula`, `!gold kaldır`, `!paraekle`, `!parasil`, `!bakım`')
     .addField("<a:k_:734314257071734804>  | __***Emoji Rol***__", '`!emojirol`, `!emojirol-log`')
     .addField(
      "<a:Fr2:734376350688870441> Linkler",
      `__***[Bot Davet Linki](https://discordapp.com/oauth2/authorize?client_id=734154453334360106&scope=bot&permissions=805314622)***__` +
        
        "**\n**" +
        `__***[Destek Sunucusu](https://discord.gg/RnWu8Ap)***__`,
      
    )
     .setFooter(`${client.user.username} - Yardim komut`, client.user.avatarURL)
     message.channel.send(ap);
   };

 

 exports.conf = {
   enabled: true,
   guildOnly: false,
   aliases: ['h', 'halp', 'help', 'y'],
   permLevel: 0
 };

 exports.help = {
   name: 'yardım',
   description: 'Tüm komutları gösterir.',
   usage: 'yardım'
 };
